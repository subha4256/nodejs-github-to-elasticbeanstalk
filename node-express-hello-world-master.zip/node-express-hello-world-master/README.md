# Simple Node Express Hello World App


![localhost:3000](/public/images/localhost_3000.png?raw=true "Node & Express")

# Steps :
```
  git clone https://github.com/eMahtab/node-express-hello-world
  cd node-express-hello-world
  npm install
  npm start

  Go to localhost:3000

```  
