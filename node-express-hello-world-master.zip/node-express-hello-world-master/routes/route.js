exports.home=function(req,res){
  res.render('home');
}


exports.login=function(req,res){ 
    res.render('login');
}

